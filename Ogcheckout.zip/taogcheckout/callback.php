<?php
/**
 *  Copyright (C) TA - All Rights Reserved
 *
 *  Unauthorized copying and editing of this file is strictly prohibited
 *  Proprietary and confidential
 *
 *  @author    TA
 *  @copyright 2020-2022 TA
 *  @license   Commercial
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../init.php');
include(dirname(__FILE__).'/taogcheckout.php');

$context = Context::getContext();

if (Tools::getIsset('trackid') && Tools::getIsset('Hash')) {
    $result = Tools::getValue('result');
    $taogcheckout = new taogcheckout();
    $track_id = Tools::getValue('trackid');
    $cart_id = $taogcheckout->getCartIdByTrackId($track_id);


    if ($cart_id) {
        try {
            $db = Db::getInstance();
            $cart = new Cart($cart_id);
            $secretkey = trim(Configuration::get('TAOGCHECKOUT_SECRET_KEY'));
            $hash = Tools::getValue('Hash');
            $refid = Tools::getValue('refid');
            $outParams = "trackid=".$track_id."&result=".$result."&refid=".$refid;
            $outHash = Tools::strtoupper(hash_hmac("sha256", $outParams, $secretkey));
            if ($hash == $outHash) {
                if (version_compare(_PS_VERSION_, '1.7', '>=')) {
                    $id_order = (int)Order::getIdByCartId($cart->id);
                } else {
                    $id_order = (int)Order::getOrderByCartId($cart->id);
                }

                if ($result == 'CAPTURED') {
                    $status = Configuration::get('TAOGCHECKOUT_SUCCESS_STATUS');
                } else {
                    $status = Configuration::get('TAOGCHECKOUT_FAILED_STATUS');
                }


                $customer = new Customer((int)$cart->id_customer);
                if (!$id_order) {
                    $currency = $context->currency;

                    $taogcheckout->validateOrder($cart_id, (int) $status, $cart->getOrderTotal(true, Cart::BOTH), $taogcheckout->displayName.'-'.$track_id, null, array(), (int)$currency->id, false, $customer->secure_key);
                    $order = new Order($taogcheckout->currentOrder);
           

                    $data = array(
                       'track_id' => pSQL($track_id),
                       'transaction_id' => pSQL($refid),
                       'id_order' => $taogcheckout->currentOrder,
                       'updated_at' => pSQL(date('Y-m-d h:m:s')),
                    );
                    $db->insert('taogcheckout_orders', $data);
                    Tools::redirect('index.php?controller=order-confirmation&id_cart=' . $cart_id . '&id_module=' . $taogcheckout->id . '&id_order=' . $taogcheckout->currentOrder . '&key=' . $customer->secure_key);
                } else {
                    $order_obj = new OrderCore($id_order);
                    $os = $order_obj->current_state;
                    if ($os != $status) {
                        $history = new OrderHistory();
                        $history->id_order = $id_order;
                        $history->changeIdOrderState($status, $id_order);
                        $history->save();
                    }
                    $db->delete(
                        'taogcheckout_cart',
                        'id_customer = ' . $cart->id_customer . ' AND id_shop = ' . $context->shop->id
                    );
                    $data = array(
                       'track_id' => pSQL($track_id),
                       'transaction_id' => pSQL($refid),
                       'id_order' => $id_order,
                       'updated_at' => pSQL(date('Y-m-d h:m:s')),
                    );
                    $exist = $db->getValue("SELECT `track_id` FROM `"._DB_PREFIX_."taogcheckout_orders` 
                    WHERE `id_order`='".$id_order."'");
                    if (!empty($exist)) {
                        $db->update('taogcheckout_orders', $data, 'id_order="'.(int)$id_order.'"');
                    } else {
                        $db->insert('taogcheckout_orders', $data);
                    }

                    Tools::redirect('index.php?controller=order-confirmation&id_cart=' . $cart_id . '&id_module=' . $taogcheckout->id . '&id_order=' . $id_order . '&key=' . $customer->secure_key);
                }
            } else {
                echo "Hash Not Matched for -".$track_id."<br/>";
                echo $hash."<br/>";
                echo $outHash;
                exit;
            }
        } catch (\Exception $e) {
            print_r($e->getMessage());
            print_r($e->getTraceAsString());
            die;
        }
    } else {
        die("Failed to get cart data");
    }
} else {
    die("Invalid url");
}
