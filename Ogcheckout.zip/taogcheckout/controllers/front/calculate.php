<?php
/**
 *  Copyright (C) TA - All Rights Reserved
 *
 *  Unauthorized copying and editing of this file is strictly prohibited
 *  Proprietary and confidential
 *
 *  @author    TA
 *  @copyright 2020-2022 TA
 *  @license   Commercial
 */

class TaogcheckoutCalculateModuleFrontController extends ModuleFrontController
{
    public $ssl = true;

    public function __construct()
    {

        parent::__construct();
        if (Tools::getIsset('orderButtonClick') && Tools::getValue('orderButtonClick')) {
            $currency = '';
            $id_cart = (int)Tools::getValue('id_cart');
            $id_customer = (int)Tools::getValue('id_customer');
            $paymentCode = Tools::getValue('payment_code');
            if (Tools::strtolower($paymentCode) == 'all') {
                $currency = trim(Configuration::get('TAOGCHECKOUT_ALL_CURRENCY'));
            } else {
                $custom_methods = array();
                $custom_methods_set = Configuration::get('TAOGCHECKOUT_CUSTOM_METHODS');
                if (is_array(json_decode($custom_methods_set, true))) {
                    $custom_methods = json_decode($custom_methods_set, true);
                }
                foreach ($custom_methods as $custom_method) {
                    if (Tools::strtolower($custom_method['code']) == Tools::strtolower($paymentCode)) {
                        $currency = $custom_method['currency'];
                        break;
                    }
                }
            }
            $cart = new Cart($id_cart);
            $this->context->cart = $cart;
            $storeCurrency = new Currency($cart->id_currency);
            $storeCurrencyCode = $storeCurrency->iso_code;

            if ($paymentCode == 'all') {
                $all_code = Configuration::get('TAOGCHECKOUT_OG_PAYMENT');
                if (Tools::strtolower($all_code) == 'currency') {
                    $paymentCode = 'currency';
                    $currency = Configuration::get('TAOGCHECKOUT_OG_CURRENCY');
                } else {
                    $currency = $storeCurrencyCode;
                }
                $doConvert = "N";
                $sourceCurrency = "";
            } else {
                if (Tools::strtolower($storeCurrencyCode) != Tools::strtolower($currency)) {
                    $doConvert = "Y";
                    $sourceCurrency = $storeCurrencyCode;
                } else {
                    $doConvert = "N";
                    $sourceCurrency = "";
                }
            }

            $description = array();
            foreach ($this->context->cart->getProducts() as $product) {
                $description[] = $product['name'];
            }
            $description = implode(' | ', $description);
            $referenceId = $this->generateRefrenceId($id_cart);
            $timestamp = date("y/m/d H:m:s t");
            $tunnel = '';
            $customer = new Customer($cart->id_customer);
            $address = new Address($cart->id_address_invoice);
            $phone = $address->phone;
            if (empty($phone)) {
                $phone = $address->phone_mobile;
            }
            $userReference = $this->generateUserRefrenceId($phone);
            $amount = $cart->getOrderTotal();
            $authKey = trim(Configuration::get('TAOGCHECKOUT_AUTH_KEY'));
            $merchantID = trim(Configuration::get('TAOGCHECKOUT_MERCHANT_CODE'));
            $secretkey = trim(Configuration::get('TAOGCHECKOUT_SECRET_KEY'));
            $datatocomputeHash = $amount . $authKey . $currency . $merchantID . $paymentCode .
                $referenceId . $sourceCurrency . $timestamp . $tunnel . $userReference;

            $hash = Tools::strtoupper(hash_hmac("sha256", $datatocomputeHash, $secretkey));

//            $callback = $this->context->link->getModuleLink('taogcheckout', 'callback');
            $callback = $this->context->shop->getBaseURL() . 'modules/taogcheckout/callback.php';
            $data = array(
                'merchantCode' => $merchantID,
                'authKey' => $authKey,
                'currency' => Tools::strtoupper($currency),
                'pc' => $paymentCode,
                'tunnel' => $tunnel,
                'amount' => (float)$amount,
                'doConvert' => $doConvert,
                'sourceCurrency' => $sourceCurrency,
                'description' => $description,
                'referenceID' => (int)$referenceId,
                'timeStamp' => $timestamp,
//                'language'=> $language,
                'callbackURL' => $callback,
                'hash' => $hash,
                'userReference' => (int)$userReference,
                'billingDetails' => array(
                    'fName' => $address->firstname,
                    'lName' => $address->lastname,
                    'mobile' => $address->phone,
                    'email' => $customer->email,
                    'city' => $address->city,
                    'pincode' => $address->postcode,
                    'state' => $address->id_state,
                    'address1' => $address->address1,
                    'address2' => $address->address2
                ),
            );

            $request = json_encode($data, true);

            $mode = Configuration::get('TAOGCHECKOUT_MODE');
            /*if ($mode == 'live') {
                $endpoint = 'https://ogpayapi.oneglobal.com/V1/api/GenToken/Validate';
            } else {
                $endpoint = 'https://ogpaystage.oneglobal.com/OgPay/V1/api/GenToken/Validate';
            }*/
            $endpoint = Configuration::get('TAOGCHECKOUT_API_URL');
            $curl = curl_init($endpoint);

            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $request);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            $ch = curl_exec($curl);
            curl_close($curl);

            $response = json_decode($ch, true);
            if (isset($response['errorCode']) && $response['errorCode'] == '0') {
                $this->updateOgCustomerCart($id_customer, $id_cart, $referenceId);
                die(json_encode(array('success' => true, 'message' => $response['result']['redirectURL'])));
            } else {
                $error = "";
                if (isset($response['errorMessgae'])) {
                    $error = $response['errorMessgae'] . ". Please choose other payment method";
                }
                die(json_encode(array('success' => false, 'message' => $error)));
            }
        }
    }

    public function updateOgCustomerCart($id_customer, $id_cart, $trackid = '')
    {
        $id_shop = (int)Tools::getValue('id_shop');
        $db = Db::getInstance();
        $id = (int)$db->getValue('
            SELECT id_taogcheckout_cart FROM ' . _DB_PREFIX_ . 'taogcheckout_cart 
            WHERE id_customer = ' . $id_customer . ' AND id_shop = ' . $id_shop);

        $data = array(
            'id_cart' => $id_cart,
            'id_shop' => $id_shop,
            'track_id' => pSQL($trackid),
            'id_customer' => $id_customer
        );

        if ($id) {
            $db->update('taogcheckout_cart', $data, 'id_taogcheckout_cart = ' . $id);
        } else {
            $db->insert('taogcheckout_cart', $data);
        }
    }

    public function generateRefrenceId($cartId)
    {

        $digits_needed = 15;

        $cartId = time() . $cartId;

        $length = Tools::strlen((int)$cartId);

        if ($length < $digits_needed) {
            $required = $digits_needed - $length;

            $id = '';
            for ($i = 1; $i <= $required; $i++) {
                $id .= 1;
            }

            $refrenceId = $id . $cartId;
        } else {
            $refrenceId = $cartId;
        }

        return (int)$refrenceId;
    }

    public function generateUserRefrenceId($uref = "")
    {

        $digits_needed = 10;
        $uref = preg_replace("/[^0-9]/", "", $uref);
        $length = Tools::strlen($uref);

        if ($length < $digits_needed) {
            $required = $digits_needed - $length;

            $id = '';
            for ($i = 1; $i <= $required; $i++) {
                $id .= 1;
            }

            $refrenceId = $id . $uref;
        } else {
            $refrenceId = $uref;
        }

        return (int)$refrenceId;
    }
}
