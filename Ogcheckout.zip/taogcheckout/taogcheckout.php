<?php
/**
 *  Copyright (C) TA - All Rights Reserved
 *
 *  Unauthorized copying and editing of this file is strictly prohibited
 *  Proprietary and confidential
 *
 *  @author    TA
 *  @copyright 2020-2022 TA
 *  @license   Commercial
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class Taogcheckout extends PaymentModule
{
    private $adminTabs = array();

    public function __construct()
    {
        $this->name = 'taogcheckout';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'Og Checkout';
        $this->secure_key = Tools::encrypt($this->name);
        $this->controllers = array('payment', 'validation');

        $this->bootstrap = true;
        parent::__construct();

        $this->adminTabs = array(
            array(
                'class' => 'AdminTaOgCheckout',
                'label' => $this->l('Og Checkout'),
                'is_parent' => true
            )
        );

        $this->displayName = $this->l('One Global');
        $this->description = $this->l('Pay with Og Checkout');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall ?');
        $this->_path = _PS_MODULE_DIR_ . 'taogcheckout/';
    }

    public function install()
    {
        if (parent::install()
            && $this->installDBTables()
            && $this->installTabs()
            && $this->registerHook('payment')
            && $this->registerHook('paymentReturn')
            && $this->registerHook('paymentOptions')
            && $this->registerHook('header')
            && $this->registerHook('displayBackOfficeHeader')
        ) {
            return true;
        }
        return false;
    }

    public function uninstall()
    {
        if (parent::uninstall()
            && $this->uninstallTabs()
            && $this->unregisterHook('payment')
            && $this->unregisterHook('paymentReturn')
            && $this->unregisterHook('paymentOptions')
            && $this->unregisterHook('header')
            && $this->unregisterHook('displayBackOfficeHeader')
        ) {
            return true;
        }

        return false;
    }

    /**
     * Add tabs in backoffice
     *
     * @return bool
     */
    public function installTabs()
    {
        $res = true;
        foreach ($this->adminTabs as $adminTab) {
            $tab = new Tab();
            $tab->name = array();
            foreach (Language::getLanguages(true) as $lang) {
                $tab->name[$lang['id_lang']] = $adminTab['label'];
            }
            $tab->class_name = $adminTab['class'];
            $tab->module = $this->name;
            if (version_compare(_PS_VERSION_, '1.7', '>=')) {
                $tab->id_parent = (int)Tab::getIdFromClassName('AdminParentPayment');
            } else {
                $tab->id_parent = 0;
            }

            $tab->icon = 'payment';
            $tab->add();
        }
        return $res;
    }

    /**
     * Remove tabs from backoffice
     *
     * @return bool
     */
    public function uninstallTabs()
    {
        $res = true;
        foreach ($this->adminTabs as $adminTab) {
            $id_tab = (int)Tab::getIdFromClassName($adminTab['class']);
            $tab = new Tab($id_tab);
            $tab->delete();
        }

        return $res;
    }

    /**
     * getContent()
     *
     * @return mixed
     */
    public function getContent()
    {
        $output = null;
        if (Tools::isSubmit('savetaogcheckoutsetting')) {
            $fields = $this->getFormValues();
            if ($pcm = Tools::getValue('TAOGCHECKOUT_CUSTOM_METHODS')) {
                $value = json_encode($pcm);
                Configuration::updateValue('TAOGCHECKOUT_CUSTOM_METHODS', $value);
                $type = Tools::getValue('TAOGCHECKOUT_PAYMENT_MODE');

                if($type == 'all') {
                  $all_code = Tools::getValue('TAOGCHECKOUT_OG_PAYMENT');

                  $all_curr = Tools::getValue('TAOGCHECKOUT_OG_CURRENCY');
                  if(trim($all_code) != 'all' && trim($all_code) != 'currency') {
                      $output .= $this->displayError('Invalid Payment Code for Og Checkout form');
                  } elseif ($all_code == 'currency' && empty($all_curr)) {
                      $output .= $this->displayError('Invalid Currency Code for Og Checkout form');
                  }
                } else {

                    foreach ($pcm as $pc) {
                        if(empty($pc['name']) || empty($pc['code']) || empty($pc['currency'])) {
                            $output .= $this->displayError('Invalid details in customize payment form
                            . Please fill all the fields.');
                        }
                    }
                }
            }

            foreach (array_keys($fields) as $key) {
                if ($key == 'TAOGCHECKOUT_CUSTOM_METHODS') {
                    continue;
                }
                if (Tools::getIsset($key)) {
                    $value = Tools::getValue($key);
                    Configuration::updateValue($key, $value);
                }
            }

            $output .= $this->displayConfirmation($this->l("Saved successfully"));
        }
        $output .= $this->renderForm();
        return $output;
    }

    protected function renderForm()
    {
        $def_lang = (int)Configuration::get('PS_LANG_DEFAULT');
        $order_states = Db::getInstance()->ExecuteS("SELECT `id_order_state`,`name` 
       FROM `" . _DB_PREFIX_ . "order_state_lang` where `id_lang` = '" . (int)$def_lang . "'");
        $custom_payments =  array();
        $custom_p = json_decode(Configuration::get('TAOGCHECKOUT_CUSTOM_METHODS'), true);
        if (is_array($custom_p)) {
            $custom_payments = $custom_p;
        }
        $this->context->smarty->assign(array(
            'custom_payments' => $custom_payments,
            'og_payment' => Configuration::get('TAOGCHECKOUT_OG_PAYMENT'),
            'og_currency' => Configuration::get('TAOGCHECKOUT_OG_CURRENCY'),
        ));
        $payment_methods = $this->context->smarty->fetch($this->_path . 'views/templates/admin/payment_methods.tpl');
        $modes = array(
          array(
              'value' => 'staging',
              'label' => 'Test Mode',
          ),
          array(
              'value' => 'live',
              'label' => 'Live Mode',
          ),
        );
        $payment_modes = array(
          array(
              'value' => 'all',
              'label' => 'Og Checkout Payment Form',
          ),
          array(
              'value' => 'custom',
              'label' => 'Customize Your Payment Form',
          ),
        );

        $fields_form = array(
            'tinymce' => true,
            'legend' => array(
                'title' => $this->l('Setting block'),
            ),
            'input' => array(
                /*array(
                    'type' => 'select',
                    'col' => 6,
                    'label' => $this->l('Mode'),
                    'hint' => $this->l('Api Mode'),
                    'desc' => $this->l('Api Mode'),
                    'name' => 'TAOGCHECKOUT_MODE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $modes,
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),*/
                array(
                    'col' => 6,
                    'type' => 'text',
                    'required' => true,
                    'label' => $this->l('Merchant Code'),
                    'hint' => $this->l('Merchant Code provided by Og Checkout'),
                    'name' => 'TAOGCHECKOUT_MERCHANT_CODE',
                    'desc' => $this->l('Merchant Code provided by Og Checkout'),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'required' => true,
                    'label' => $this->l('Auth Key'),
                    'name' => 'TAOGCHECKOUT_AUTH_KEY',
                    'hint' => $this->l('Auth Key provided by Og Checkout'),
                    'desc' => $this->l('Auth Key provided by Og Checkout'),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'required' => true,
                    'label' => $this->l('Secret Key'),
                    'name' => 'TAOGCHECKOUT_SECRET_KEY',
                    'hint' => $this->l('Secret Key provided by Og Checkout'),
                    'desc' => $this->l('Secret Key provided by Og Checkout'),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'required' => true,
                    'label' => $this->l('Endpoint Url'),
                    'hint' => $this->l('Endpoint Url'),
                    'name' => 'TAOGCHECKOUT_API_URL',
                    'desc' => $this->l('Endpoint Url'),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'label' => $this->l('Tunnel'),
                    'name' => 'TAOGCHECKOUT_TUNNEL',
                    'hint' => $this->l('Provided by OG  if requires.'),
                    'desc' => $this->l('Provided by OG  if requires.'),
                ),
                array(
                    'type' => 'select',
                    'col' => 8,
                    'label' => $this->l('Success Order status'),
                    'hint' => $this->l('Order status for order when payment is successfull'),
                    'desc' => $this->l('Order status for order when payment is successfull'),
                    'name' => 'TAOGCHECKOUT_SUCCESS_STATUS',
                    'required' => true,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'col' => 8,
                    'label' => $this->l('Failed Order status'),
                    'hint' => $this->l('Order status for order when payment is failed.'),
                    'desc' => $this->l('Order status for order when payment is failed.'),
                    'name' => 'TAOGCHECKOUT_FAILED_STATUS',
                    'required' => true,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Payment Type'),
                    'hint' => $this->l('Payment Type'),
                    'desc' => $this->l('Payment Type'),
                    'name' => 'TAOGCHECKOUT_PAYMENT_MODE',
                    'required' => true,
                    'default_value' => '',
                    'options' => array(
                        'query' => $payment_modes,
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),
                array(
                    'type' => 'html',
                    'col' => 8,
                    'label' => $this->l('Payment Configuration'),
                    'hint' => $this->l('Payment Configuration'),
                    'name' => $payment_methods
                ),
              /*  array(
                    'col' => 6,
                    'type' => 'text',
                    'label' => $this->l('Og Checkout Currency Code'),
                    'name' => 'TAOGCHECKOUT_ALL_CURRENCY',
                    'hint' => $this->l('Enter Og Checkout Currency Code'),
                    'desc' => $this->l('Enter Og Checkout Currency Code'),
                ),*/
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            ),
            'buttons' => array(
                array(
                    'href' => AdminController::$currentIndex.'&configure='.$this->name.'&token='.
                        Tools::getAdminTokenLite('AdminModules'),
                    'title' => $this->l('Back'),
                    'icon' => 'process-icon-back'
                )
            )
        );


        $helper = new HelperForm();
        $helper->module = $this;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        foreach (Language::getLanguages(false) as $lang) {
            $helper->languages[] = array(
                'id_lang' => $lang['id_lang'],
                'iso_code' => $lang['iso_code'],
                'name' => $lang['name'],
                'is_default' => ($def_lang == $lang['id_lang'] ? 1 : 0)
            );
        }

        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->default_form_language = $def_lang;
        $helper->allow_employee_form_lang = $def_lang;
        $helper->toolbar_scroll = true;
        $helper->title = $this->displayName;
        $helper->submit_action = 'savetaogcheckoutsetting';

        $helper->fields_value = $this->getFormValues();

        return $helper->generateForm(array(array('form' => $fields_form)));
    }


    public function getFormValues()
    {
        return array(
            'TAOGCHECKOUT_MODE' => Configuration::get('TAOGCHECKOUT_MODE') ?
                Configuration::get('TAOGCHECKOUT_MODE') : 'staging',
            'TAOGCHECKOUT_MERCHANT_CODE' => Configuration::get('TAOGCHECKOUT_MERCHANT_CODE') ?
                Configuration::get('TAOGCHECKOUT_MERCHANT_CODE') : '',
            'TAOGCHECKOUT_AUTH_KEY' => Configuration::get('TAOGCHECKOUT_AUTH_KEY') ?
                Configuration::get('TAOGCHECKOUT_AUTH_KEY') : '',
            'TAOGCHECKOUT_SECRET_KEY' => Configuration::get('TAOGCHECKOUT_SECRET_KEY') ?
                Configuration::get('TAOGCHECKOUT_SECRET_KEY') : '',
            'TAOGCHECKOUT_API_URL' => Configuration::get('TAOGCHECKOUT_API_URL') ?
                Configuration::get('TAOGCHECKOUT_API_URL') : '',
            'TAOGCHECKOUT_TUNNEL' => Configuration::get('TAOGCHECKOUT_TUNNEL') ?
                Configuration::get('TAOGCHECKOUT_TUNNEL') : '',
            'TAOGCHECKOUT_SUCCESS_STATUS' => Configuration::get('TAOGCHECKOUT_SUCCESS_STATUS') ?
                Configuration::get('TAOGCHECKOUT_SUCCESS_STATUS') : '',
            'TAOGCHECKOUT_FAILED_STATUS' => Configuration::get('TAOGCHECKOUT_FAILED_STATUS') ?
                Configuration::get('TAOGCHECKOUT_FAILED_STATUS') : '',
            'TAOGCHECKOUT_PAYMENT_MODE' => Configuration::get('TAOGCHECKOUT_PAYMENT_MODE') ?
                Configuration::get('TAOGCHECKOUT_PAYMENT_MODE') : '',
            'TAOGCHECKOUT_ALL_CURRENCY' => Configuration::get('TAOGCHECKOUT_ALL_CURRENCY') ?
                Configuration::get('TAOGCHECKOUT_ALL_CURRENCY') : '',
            'TAOGCHECKOUT_CUSTOM_METHODS' => Configuration::get('TAOGCHECKOUT_CUSTOM_METHODS') ?
                Configuration::get('TAOGCHECKOUT_CUSTOM_METHODS') : '',
            'TAOGCHECKOUT_OG_PAYMENT' => Configuration::get('TAOGCHECKOUT_OG_PAYMENT') ?
                Configuration::get('TAOGCHECKOUT_OG_PAYMENT') : '',
            'TAOGCHECKOUT_OG_CURRENCY' => Configuration::get('TAOGCHECKOUT_OG_CURRENCY') ?
                Configuration::get('TAOGCHECKOUT_OG_CURRENCY') : '',

        );
    }

    public function hookDisplayBackOfficeHeader()
    {
        $this->context->controller->addJquery();
        if ($this->context->controller->controller_name == 'AdminModules') {
            $this->context->controller->addJS($this->_path . 'views/js/admin/ogcheckout.js');
        }
    }



    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return '';
        }
        $active = true;

        if (version_compare(_PS_VERSION_, '1.7', '>=')) {
            if ($active) {
                $payment_options = array();
                $type = Configuration::get('TAOGCHECKOUT_PAYMENT_MODE');
                if ($type == 'all') {
                    $call_to_action_text = 'Pay by OgCheckout';

                    $payOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
                    $payOption->setCallToActionText($call_to_action_text)
                        ->setModuleName('taogcheckout-all')
                        ->setLogo('https://checkoutadmin.oneglobal.com/pgimages/ogcheckout.png')
//                        ->setAction($this->context->link->getModuleLink($this->name,
// 'validation', array('id_plan' => $plan['id_plan']), true))
//                        ->setAdditionalInformation($this->context->smarty->fetch($this->_path .
// 'views/templates/front/additional_information.tpl'))
                        ->setForm($this->generatePaymentForm('all'))
                    ;

                    $payment_options[] = $payOption;
                } else {
                    $custom_methods = array();
                    $custom_methods_set = Configuration::get('TAOGCHECKOUT_CUSTOM_METHODS');
                    if (is_array(json_decode($custom_methods_set, true))) {
                        $custom_methods = json_decode($custom_methods_set, true);
                    }


                    foreach ($custom_methods as $custom_method) {
                        $call_to_action_text = $custom_method['name'].' by OgCheckout';
                        $payOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
                        $this->context->smarty->assign(
                            'logo_path',
                            'https://checkoutadmin.oneglobal.com/pgimages/'.$custom_method['code'].'.png'
                        );

                        $payOption->setCallToActionText($call_to_action_text)
                        ->setModuleName('taogcheckout-'.$custom_method['code'])
                        ->setLogo('https://checkoutadmin.oneglobal.com/pgimages/'.
                            $custom_method['code'].'.png')
    //                        ->setAction($this->context->link->getModuleLink($this->name,
    // 'validation', array('id_plan' => $plan['id_plan']), true))
    //                        ->setAdditionalInformation($this->context->smarty->fetch($this->_path .
    // 'views/templates/front/additional_information.tpl'))
                        ->setForm($this->generatePaymentForm($custom_method['code']))
                        ;

                        $payment_options[] = $payOption;
                    }
                }
                return $payment_options;
            } else {
                return '';
            }
        } else {
            if ($active) {
                $methods = array();
                $type = Configuration::get('TAOGCHECKOUT_PAYMENT_MODE');
                if ($type == 'all') {
                    $method = array(
                      'name' => 'Pay by Og Checkout',
                      'logo' => 'https://checkoutadmin.oneglobal.com/pgimages/ogcheckout.png',
                      'payment_code' => 'all',
                    );
                    $methods[] = $method;
                } else {
                    $custom_methods = array();
                    $custom_methods_set = Configuration::get('TAOGCHECKOUT_CUSTOM_METHODS');
                    if (is_array(json_decode($custom_methods_set, true))) {
                        $custom_methods = json_decode($custom_methods_set, true);
                    }
                    foreach ($custom_methods as $custom_method) {
                        $method = array(
                            'name' => $custom_method['name'].' by Og Checkout',
                            'logo' => 'https://checkoutadmin.oneglobal.com/pgimages/'.$custom_method['code'].'.png',
                            'payment_code' => $custom_method['code'],
                        );
                        $methods[] = $method;
                    }
                }


                $cart = $this->context->cart;

                $this->smarty->assign(array(
                    'methods' => $methods,
                    'id_cart' => (int)$cart->id,
                    'ogcheckout_ajax_url' => $this->context->link->getModuleLink('taogcheckout', 'calculate'),
                    'id_shop' => (int)$this->context->shop->id,
                    'id_customer' => (int)$this->context->customer->id,
                ));

                return $this->display($this->name, 'payment_16.tpl');
            }
        }
    }

    private function generatePaymentForm($payment_code)
    {
        $cart = $this->context->cart;
        $total = $cart->getOrderTotal();


        $this->context->smarty->assign(array(
            'cart_id' => (int)$cart->id,
            'price' => $total,
            'email' => $this->context->customer->email,
            'payment_code' => $payment_code,
            'ogcheckout_ajax_url' => $this->context->link->getModuleLink('taogcheckout', 'calculate'),
            'shop_id' => (int)$this->context->shop->id,
            'customer_id' => (int)$this->context->customer->id
        ));

        $toReturn = $this->context->smarty->fetch('module:taogcheckout/views/templates/front/payment_form.tpl');

        return $toReturn;
    }

    public function hookPayment($params)
    {
        return $this->hookPaymentOptions($params);
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }
        return '';

//        return $this->display($this->name, 'confirmation.tpl');
    }

    public function hookHeader($params)
    {

        if ($this->context->controller->php_self == 'order') {
            $this->clearTableCart();
        }

        if (version_compare(_PS_VERSION_, '1.7', '>=')) {
            $this->context->controller->addJS(($this->_path) . 'views/js/front/front.js');
        } else {
            $this->context->controller->addJS(($this->_path) . 'views/js/front/front16.js');
        }
    }

    private function clearTableCart()
    {

        $id_shop = (int) $this->context->shop->id;
        $id_customer = (int) $this->context->customer->id;

        Db::getInstance()->delete('taogcheckout_cart', 'id_shop = '.$id_shop.
            ' AND id_customer = '.$id_customer);
    }

    public function installDBTables()
    {
        $db = Db::getInstance();
        return $db->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'taogcheckout_orders` (
            `id` int(15) NOT NULL auto_increment,
            `track_id` varchar(150) NOT NULL,
            `transaction_id` varchar(150) NOT NULL,
            `id_order` int(15) NOT NULL,
            `updated_at` datetime,
            PRIMARY KEY (`id`)
              )') &&
            $db->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'taogcheckout_cart` (
            `id_taogcheckout_cart` int(10) auto_increment,
			`id_cart` int(10) NOT NULL,
			`id_shop` int(10) NOT NULL DEFAULT 1,
			`id_customer` int(10) NOT NULL,
			`track_id` varchar(150) NOT NULL,
            PRIMARY KEY (`id_taogcheckout_cart`)
            )');
    }

    public function getCartIdByTrackId($trackId)
    {
        return Db::getInstance()->getValue("SELECT `id_cart` FROM `"._DB_PREFIX_."taogcheckout_cart`
         WHERE `track_id`='".pSQL($trackId)."'");
    }
}
